import SwiftUI

struct RecipeNotSelectedView: View {
    var body: some View {
        Text("Select a recipe.")
    }
}
